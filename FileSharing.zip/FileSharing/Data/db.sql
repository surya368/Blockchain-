/* SQLyog Community Edition- MySQL GUI v6.07 Host - 5.5.30 : Database - 
/* SQLyog Community Edition- MySQL GUI v6.07 Host - 5.5.30 : Database - 
/* SQLyog Community Edition- MySQL GUI v6.07 Host - 5.5.30 : Database - 
/* SQLyog Community Edition- MySQL GUI v6.07 Host - 5.5.30 : Database - 